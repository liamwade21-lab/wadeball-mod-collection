# Viltrumite Powers installer, run by INSTALL.bat. Finds WorldBox (Steam), checks WorldFall is
# there and WorldBox is closed, then copies Viltrumite.dll and the Viltrumite folder from this
# package's "mods" folder into WorldBox's mods folder. An existing viltrumite.json (your
# settings) is kept; sounds, animations and models an older version had that this one doesn't
# ship are removed.
#   -WorldBox <folder>  use this WorldBox folder instead of looking for it
#   -DryRun             only say what it would do
param(
    [string]$WorldBox = "",
    [switch]$DryRun
)
$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
$from = Join-Path $here "mods"

function Say([string]$text, [string]$color = "Gray") { Write-Host $text -ForegroundColor $color }

function Finish([int]$code) {
    if (-not $DryRun) {
        Write-Host ""
        Read-Host "Press Enter to close" | Out-Null
    }
    exit $code
}

# The mods folder of the WorldBox install at (or around) a folder: the WorldBox folder itself
# or any folder inside it, such as its mods folder. $null if there's no worldbox.exe.
function ModsIn([string]$folder) {
    if (-not $folder) { return $null }
    $dir = $folder.Trim().Trim('"').TrimEnd('\')
    for ($i = 0; $i -lt 4 -and $dir; $i++) {
        if (Test-Path (Join-Path $dir "worldbox.exe")) {
            return (Join-Path $dir "worldbox_Data\StreamingAssets\mods")
        }
        $dir = Split-Path $dir -Parent
    }
    return $null
}

# Every Steam library folder: Steam's own, and the ones in libraryfolders.vdf.
function SteamLibraries {
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($key in "HKCU:\Software\Valve\Steam", "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam", "HKLM:\SOFTWARE\Valve\Steam") {
        try {
            $p = Get-ItemProperty $key -ErrorAction Stop
            foreach ($name in "SteamPath", "InstallPath") {
                if ($p.$name) { $roots.Add(($p.$name -replace "/", "\")) }
            }
        } catch { }
    }
    $roots.Add("C:\Program Files (x86)\Steam")
    $roots.Add("C:\Program Files\Steam")
    $libs = New-Object System.Collections.Generic.List[string]
    foreach ($r in $roots) {
        if (-not (Test-Path $r)) { continue }
        $libs.Add($r)
        $vdf = Join-Path $r "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            foreach ($line in Get-Content $vdf) {
                if ($line -match '"path"\s+"([^"]+)"') { $libs.Add(($Matches[1] -replace "\\\\", "\")) }
            }
        }
    }
    return $libs | Select-Object -Unique
}

Say "Viltrumite Powers installer" "Cyan"
Say "===========================" "Cyan"
Say ""

# The package must be unzipped, not run from inside the zip.
if (-not (Test-Path (Join-Path $from "Viltrumite.dll")) -or -not (Test-Path (Join-Path $from "Viltrumite\0Harmony.dll"))) {
    Say "Can't find the mod files next to this installer." "Red"
    Say "Unzip the whole download first (right-click the zip > Extract All), then double-click"
    Say "INSTALL.bat inside the unzipped folder."
    Finish 1
}

# Find WorldBox.
$mods = $null
if ($WorldBox) {
    $mods = ModsIn $WorldBox
} else {
    foreach ($lib in SteamLibraries) {
        $mods = ModsIn (Join-Path $lib "steamapps\common\worldbox")
        if ($mods) { break }
    }
}
while (-not $mods) {
    Say "Couldn't find WorldBox automatically." "Yellow"
    Say "In Steam: right-click WorldBox > Manage > Browse local files, copy that folder's path"
    Say "from the address bar and paste it here (or just press Enter to give up)."
    if ($DryRun) { Finish 1 }
    $typed = Read-Host "WorldBox folder"
    if (-not $typed) { Finish 1 }
    $mods = ModsIn $typed
    if (-not $mods) { Say "There's no worldbox.exe in that folder." "Red"; Say "" }
}
Say ("WorldBox mods folder: " + $mods)

# WorldFall has to be there already.
if (-not (Test-Path (Join-Path $mods "Worldfall.dll"))) {
    Say ""
    Say "WorldFall isn't installed (no Worldfall.dll in the mods folder)." "Red"
    Say "Viltrumite Powers needs WorldFall 0.9.8.9. Install WorldFall first, start WorldBox once"
    Say "to check it works, then run this installer again."
    Finish 1
}

# WorldBox has to be closed (its files are locked while it runs).
while (Get-Process worldbox -ErrorAction SilentlyContinue) {
    Say ""
    Say "WorldBox is running. Close it, then press Enter." "Yellow"
    if ($DryRun) { break }
    Read-Host | Out-Null
}

$data = Join-Path $mods "Viltrumite"
$json = Join-Path $data "viltrumite.json"
$keepJson = Test-Path $json
if ($DryRun) {
    Say ""
    Say "Dry run: would copy Viltrumite.dll and the Viltrumite folder into the mods folder" "Cyan"
    Say ("  settings: " + $(if ($keepJson) { "keep the existing viltrumite.json" } else { "install the default viltrumite.json" }))
    Finish 0
}

try {
    Say ""
    Say "Installing..."
    New-Item -ItemType Directory -Force $data | Out-Null
    Copy-Item (Join-Path $from "Viltrumite.dll") (Join-Path $mods "Viltrumite.dll") -Force
    Copy-Item (Join-Path $from "Viltrumite\0Harmony.dll") (Join-Path $data "0Harmony.dll") -Force
    if (-not $keepJson) { Copy-Item (Join-Path $from "Viltrumite\viltrumite.json") $json -Force }
    foreach ($folder in "sounds", "anims", "models") {
        $src = Join-Path $from ("Viltrumite\" + $folder)
        $dst = Join-Path $data $folder
        New-Item -ItemType Directory -Force $dst | Out-Null
        Copy-Item (Join-Path $src "*") $dst -Force
        # Sounds, animations and models an older version had and this one doesn't.
        Get-ChildItem $dst -File | Where-Object { $_.Extension -in ".wav", ".clip", ".glb" -and -not (Test-Path (Join-Path $src $_.Name)) } |
            ForEach-Object { Remove-Item $_.FullName -Force }
    }
    # Files from a downloaded zip are marked as from the internet; clear that.
    Get-ChildItem $data -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
    Unblock-File (Join-Path $mods "Viltrumite.dll") -ErrorAction SilentlyContinue
}
catch {
    Say ""
    Say ("Couldn't copy the files: " + $_.Exception.Message) "Red"
    Say "Make sure WorldBox is closed. If it still fails, right-click INSTALL.bat and choose"
    Say "'Run as administrator', or copy the files by hand (see HOW TO INSTALL.txt)."
    Finish 1
}

Say ""
Say "Done! Viltrumite Powers is installed." "Green"
if ($keepJson) { Say "Your existing settings (viltrumite.json) were kept." }
Say ""
Say "Start WorldBox, possess a person with WorldFall (G), and press T to switch the powers on."
Say "Back up your world first: smashed towns and craters stay when the world saves."
Finish 0
