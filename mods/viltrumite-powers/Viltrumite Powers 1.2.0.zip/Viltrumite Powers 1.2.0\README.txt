Viltrumite Powers 1.2.0
For WorldBox + WorldFall 0.9.8.9
================================

BACK UP YOUR WORLD before trying the powers. Smashed buildings, craters, burnt-down towns and
everyone you punch stay that way when the world saves, and there's no undo. Flying supersonic
through a town sets every building you hit off like a bomb, with fire. At 5 boost stacks the first
tree or building you hit is a max-stack bomb: 20 tiles of fire and craters under a mushroom cloud.


What it does
------------
While you possess a person in WorldFall, Viltrumite Powers lets them fly like a Viltrumite
from Invincible: hover, fast flight, supersonic flight with a sonic boom that blows apart
the buildings and trees you fly into, cratering dive landings, punches that launch people
across the map, grabbing and throwing, and full invincibility. A third-person camera follows you while the
powers are on, and you look the part: with powers on you're drawn as Omni-Man (white suit, red
cape, gloves, boots and belt, black hair and moustache), and your cape hangs, sways and streams
out behind you as you fly.


Install
-------
1. You need WorldBox with WorldFall 0.9.8.9 already working.
2. Close WorldBox.
3. Easiest: unzip the download and double-click INSTALL.bat (see HOW TO INSTALL.txt).
   By hand: copy Viltrumite.dll and the Viltrumite folder into WorldBox's mods folder:
     ...\Steam\steamapps\common\worldbox\worldbox_Data\StreamingAssets\mods
   (In Steam: right-click WorldBox > Manage > Browse local files, then open
   worldbox_Data\StreamingAssets\mods.) You should end up with:
     mods\Viltrumite.dll
     mods\Viltrumite\   (0Harmony.dll, viltrumite.json, sounds, anims, models)
4. Start WorldBox, possess a person (G), and press T.
   (Or F2 > Game > Viltrumite Powers.)

Updating: install the new version the same way; your viltrumite.json settings are kept.
Uninstall: delete mods\Viltrumite.dll and the mods\Viltrumite folder.


Keys (while powers are on)
--------------------------
T                Powers on / off. Change it in F2 > Game > Powers key: T, K, V, or menu only.
                 (With V, WorldFall's own map view moves to Shift+V.)
Space            On the ground: tap to take off. Hold to charge, let go to launch into fast
                 flight where you look. In the air: tap to drop, hold to charge a boost and
                 let go to launch.
                 A full boost breaks the sound barrier: sonic boom.
                 Supersonic: hold Space until the bar is full and let go for a boost stack
                 (x1.5 speed each, up to 5 stacks: 46 > 69 > 104 > 155 > 233 > 349 tiles a
                 second), each with a sonic boom. Letting go early does nothing up there.
W twice          Hover -> fast flight
S twice          Fast flight -> hover
W / S            Speed up / slow down in fast flight. S also drops all your boost stacks at
                 once (back to normal supersonic speed).
WASD + mouse     Hovering: move where you look (look up and press W to rise)
Mouse            Fast flight: steer
Ctrl             Fast flight: dive straight down into a cratering landing. Let go to pull up.
Shift + W        On the ground: run at 8 tiles a second (people in the way are only pushed
                 aside, your own kingdom's people too).
Shift + W twice  On the ground, holding Shift: a super run at 20 tiles a second, starting
                 with a sonic boom. It ploughs through people, buildings and trees while
                 you hold Shift + W (plants, crops and rocks it just runs over). Tap Space
                 mid-run to take off into fast flight at that speed.
Left mouse       Punch. Quick clicks chain a combo. Hold, then let go: a charged punch that
                 blows up like a bomb (no fire) where it lands. The longer you hold (up to
                 about 2 seconds, when your fist flashes), the bigger the blast.
                 While holding someone: click to throw them where you aim. Hold, then let
                 go: a charged throw that slams them into the ground hard enough to leave
                 a crater (bigger the longer you held).
Q                Grab the creature you're aiming at by the neck (up to cow size) / let go.

Always yours, even with powers on: Esc (pause), F2 (WorldFall's menu), G (leave the creature).
On the ground you walk the normal WorldFall way, half as fast again.


Good to know
------------
- Only people can have powers, and not in multiplayer.
- The Omni-Man look: anyone with powers on (man, woman, child, elf, orc or dwarf) is drawn as
  Omni-Man at their own height, bare-handed (no weapon, tool, hat or crown until the powers go
  off). Switching powers on or off swaps the look in a flash of white and a ring of dust; off in
  the air, you stay Omni-Man until you land. Turn it off (or back on) in F2 > Game > Omni-Man
  look; it's remembered. If the model can't load, you keep your own look and get one message.
  The cape is stiff panels, not cloth, so it can pass through an arm or leg in some poses.
- The keys for what you're doing are shown in a line at the bottom of the screen, just
  above WorldFall's health and stamina bars.
- Flying supersonic you plough straight through towns and forests and don't slow down.
  Every building you hit goes up like a WorldBox bomb, fire and craters included; every tree
  bursts in a blast just as big, but with no fire and the ground left as it was.
- Boost stacks: each tree or building you smash costs one stack (plants, crops and rocks
  don't), and the blasts grow 2 tiles a stack. Steering gets sharper with every stack. A
  dive, a double-tap S, a landing or a splash ends them. From stack 1 you glow with heat, from
  stack 2 you burn like a meteor (looks only: it sets nothing on fire). Near the map's edge
  you're swung back inside, stacks and all.
- Skimming low and supersonic (within 6 tiles) tears up dust over land and spray over water.
- Flying low over water you stay just above it (your lowest point 0.3 m up) and never vanish
  under it.
- Hovering slowly, you float over plants, crops and rocks, and slide round trees and along
  walls instead of bumping into them.
- With powers on you stay out of houses, mines and boat cabins. Switch them off to go in.
- Nothing can hurt you while the powers are on. Switching off in the air lowers you down
  gently; so does leaving the person mid-flight.
- The sonic boom and the wake behind supersonic flight knock people over but never hurt them.
- Settings: mods\Viltrumite\viltrumite.json (speeds, damage, camera, shake, limits). It's read
  each time powers turn on, so you can tweak it without restarting. A broken file just falls
  back to the defaults. Set "lowShake": true if the camera shake is too much.
- Something wrong? Search WorldBox's log for [Viltrumite]:
    %USERPROFILE%\AppData\LocalLow\mkarpenko\WorldBox\Player.log
  If a WorldFall update changes something the powers rely on, the mod switches itself off
  with one message and WorldFall carries on as normal.


Credits
-------
Flying, punching and landing sounds and animations come from the GTA V mod "Superman V2.2"
by JulioNIB (NIB Mods).
