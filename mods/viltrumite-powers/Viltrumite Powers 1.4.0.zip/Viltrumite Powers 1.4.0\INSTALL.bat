@echo off
rem Viltrumite Powers: double-click to install into WorldBox (see HOW TO INSTALL.txt).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
