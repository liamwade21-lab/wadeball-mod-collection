Viltrumite Powers 1.4.0
For WorldBox + WorldFall 0.9.8.9
================================

BACK UP YOUR WORLD before trying the powers. Smashed buildings, craters, burnt-down towns and
everyone you punch stay that way when the world saves, and there's no undo. Flying supersonic
through a town sets every building you hit off like a bomb, with fire. From 2 boost stacks the
first tree or building you hit is an atomic bomb: 20 tiles of fire and craters under a mushroom
cloud, at most one every 4 seconds.


What's new in 1.4.0
-------------------
- Multiplayer: the powers work in WorldFall multiplayer games, for the host and for every
  guest with the same Viltrumite version (see Multiplayer below).
- Everyone sees everyone's powers: the Omni-Man look, the cape, the flying poses, the glow and
  burn of boost stacks, the trails, the sonic booms and the sounds.
- Smashed towns, bombs, fires, craters and people sent flying happen in the host's world, for
  everyone, whoever did it.
- Players can punch, grab and throw each other. Powered players are knocked back but never hurt.
- The host chooses who gets powers: F2 > Game > Powers in multiplayer (Everyone, Host only or
  Nobody).
- The mod is now just Viltrumite.dll and its settings file: the sounds, animations and model are
  inside the DLL, so guests can get it through WorldFall's own mod download.


What's new in 1.3.0
-------------------
- Target marker: gold corners frame the creature Q would grab, once it's in reach. Turn it off
  in F2 > Game > Target marker. The centre cross stays.
- Boost stacks charge twice as fast: 0.7 seconds of holding Space in supersonic flight (the
  launch from a hover or the ground still takes 1.4).
- Smashing trees and buildings no longer costs boost stacks: you keep your speed.
- The atomic bomb goes off from stack 2 (it used to need all 5), then ordinary stacked blasts
  for 4 seconds, then the next hit is a bomb again.
- The centre cross, the charge bar and the controls line at the bottom show again: WorldFall's
  view was being drawn over them.
- Winding up a punch while walking or running, your legs keep moving and only the upper body
  draws back the punch (standing still, you still plant your feet).
- Four new settings in viltrumite.json (an older file gets the defaults; see Good to know):
  speed.stackChargeSeconds (0.7), speed.hitsCostStacks (0; 1 brings back losing a stack per
  hit), smash.atomicBombFromStack (2), smash.atomicBombCooldown (4 seconds).


What it does
------------
While you possess a person in WorldFall, Viltrumite Powers lets them fly like a Viltrumite
from Invincible: hover, fast flight, supersonic flight with a sonic boom that blows apart
the buildings and trees you fly into, cratering dive landings, punches that launch people
across the map, grabbing and throwing, and full invincibility. A third-person camera follows you while the
powers are on, and you look the part: with powers on you're drawn as Omni-Man (white suit, red
cape, gloves, boots and belt, black hair and moustache), and your cape hangs, sways and streams
out behind you as you fly.


Install
-------
1. You need WorldBox with WorldFall 0.9.8.9 already working.
2. Close WorldBox.
3. Easiest: unzip the download and double-click INSTALL.bat (see HOW TO INSTALL.txt).
   By hand: copy Viltrumite.dll and the Viltrumite folder into WorldBox's mods folder:
     ...\Steam\steamapps\common\worldbox\worldbox_Data\StreamingAssets\mods
   (In Steam: right-click WorldBox > Manage > Browse local files, then open
   worldbox_Data\StreamingAssets\mods.) You should end up with:
     mods\Viltrumite.dll           (the sounds, animations and model are inside it)
     mods\Viltrumite\viltrumite.json
4. Start WorldBox, possess a person (G), and press T.
   (Or F2 > Game > Viltrumite Powers.)

Updating: install the new version the same way; your viltrumite.json settings are kept. From
1.4.0 the old mods\Viltrumite\0Harmony.dll and the sounds, anims and models folders aren't
needed (the installer removes them).
Uninstall: delete mods\Viltrumite.dll and the mods\Viltrumite folder.


Multiplayer
-----------
Viltrumite Powers works in WorldFall multiplayer games. The host's game runs the world, so:
- Who gets powers is the host's choice: F2 > Game > Powers in multiplayer: Everyone (the
  default), Host only, or Nobody (host included). Guests see the host's choice there, greyed
  out. If the host turns them off for you mid-flight, you come down gently.
- Everyone plays by the host's viltrumite.json (speeds, damage, blast sizes), except each
  player's own camera and shake settings. Yours come back when you leave.
- Guests need the same Viltrumite version as the host. When you join, WorldFall offers to
  download the host's mods; tick "I trust this host" and Viltrumite.dll comes with them. With
  another version (or none) you play WorldFall normally and see powered players as ordinary
  people; you get a notice saying which version the host has.
- Your own flying feels the same as on your own. What you smash, burn or blow up happens in
  the host's world a moment later (about one ping), for everyone.
- Punching, blasting and throwing other players knocks them back. It only hurts players whose
  powers are off, and only with WorldFall's PvP rule on.
- Q grabs another player too. Held, you can't move; with your powers on, Space breaks free into
  a hover (or press G to leave the body, as always).
- If the host leaves or you're disconnected, the powers switch off and WorldFall takes you back
  to your own world.
- The host's game checks every guest's smash, punch and blast (near their body, with their
  powers on, not too many at once), so a broken or cheating copy can't wreck the whole map.


Keys (while powers are on)
--------------------------
T                Powers on / off. Change it in F2 > Game > Powers key: T, K, V, or menu only.
                 (With V, WorldFall's own map view moves to Shift+V.)
Space            On the ground: tap to take off. Hold to charge, let go to launch into fast
                 flight where you look. In the air: tap to drop, hold to charge a boost and
                 let go to launch.
                 A full boost breaks the sound barrier: sonic boom.
                 Supersonic: hold Space until the bar is full (0.7 seconds) and let go for a
                 boost stack (x1.5 speed each, up to 5 stacks: 46 > 69 > 104 > 155 > 233 > 349
                 tiles a second), each with a sonic boom. Letting go early does nothing up there.
W twice          Hover -> fast flight
S twice          Fast flight -> hover
W / S            Speed up / slow down in fast flight. S also drops all your boost stacks at
                 once (back to normal supersonic speed).
WASD + mouse     Hovering: move where you look (look up and press W to rise)
Mouse            Fast flight: steer
Ctrl             Fast flight: dive straight down into a cratering landing. Let go to pull up.
Shift + W        On the ground: run at 8 tiles a second (people in the way are only pushed
                 aside, your own kingdom's people too).
Shift + W twice  On the ground, holding Shift: a super run at 20 tiles a second, starting
                 with a sonic boom. It ploughs through people, buildings and trees while
                 you hold Shift + W (plants, crops and rocks it just runs over). Tap Space
                 mid-run to take off into fast flight at that speed.
Left mouse       Punch. Quick clicks chain a combo. Hold, then let go: a charged punch that
                 blows up like a bomb (no fire) where it lands. The longer you hold (up to
                 about 2 seconds, when your fist flashes), the bigger the blast.
                 While holding someone: click to throw them where you aim. Hold, then let
                 go: a charged throw that slams them into the ground hard enough to leave
                 a crater (bigger the longer you held).
Q                Grab the creature you're aiming at by the neck (up to cow size) / let go.
                 Gold corners show who Q would grab.

Always yours, even with powers on: Esc (pause), F2 (WorldFall's menu), G (leave the creature).
On the ground you walk the normal WorldFall way, half as fast again.


Good to know
------------
- Only people can have powers (in multiplayer too: see Multiplayer).
- The Omni-Man look: anyone with powers on (man, woman, child, elf, orc or dwarf) is drawn as
  Omni-Man at their own height, bare-handed (no weapon, tool, hat or crown until the powers go
  off). Switching powers on or off swaps the look in a flash of white and a ring of dust; off in
  the air, you stay Omni-Man until you land. Turn it off (or back on) in F2 > Game > Omni-Man
  look; it's remembered. If the model can't load, you keep your own look and get one message.
  The cape is stiff panels, not cloth, so it can pass through an arm or leg in some poses.
- The keys for what you're doing are shown in a line at the bottom of the screen, just
  above WorldFall's health and stamina bars.
- The target marker: gold corners frame the creature Q would grab right now, once it's in
  reach (about 3 tiles). None while you hold someone. Turn it off (or back on) in F2 > Game >
  Target marker; it's remembered. The centre cross shows either way.
- Flying supersonic you plough straight through towns and forests and don't slow down.
  Every building you hit goes up like a WorldBox bomb, fire and craters included; every tree
  bursts in a blast just as big, but with no fire and the ground left as it was.
- Boost stacks: smashing trees and buildings costs no stacks, and the blasts grow 2 tiles a
  stack. From stack 2 the first tree or building you hit is the atomic bomb (20 tiles, fire,
  mushroom cloud); for the next 4 seconds hits are ordinary stacked blasts, then the next one
  is a bomb again. Steering gets sharper with every stack. S, a dive, hovering, slowing below
  the sound barrier, a landing or a splash ends them. From stack 1 you glow with heat, from
  stack 2 you burn like a meteor (looks only: it sets nothing on fire). Near the map's edge
  you're swung back inside, stacks and all.
- Skimming low and supersonic (within 6 tiles) tears up dust over land and spray over water.
- Flying low over water you stay just above it (your lowest point 0.3 m up) and never vanish
  under it.
- Hovering slowly, you float over plants, crops and rocks, and slide round trees and along
  walls instead of bumping into them.
- With powers on you stay out of houses, mines and boat cabins. Switch them off to go in.
- Nothing can hurt you while the powers are on. Switching off in the air lowers you down
  gently; so does leaving the person mid-flight.
- The sonic boom and the wake behind supersonic flight knock people over but never hurt them.
- Settings: mods\Viltrumite\viltrumite.json (speeds, damage, camera, shake, limits). It's read
  each time powers turn on, so you can tweak it without restarting. A broken file just falls
  back to the defaults. Set "lowShake": true if the camera shake is too much. Settings a newer
  version adds use their defaults until you add them to your file. 1.3.0's four:
    "speed":  "stackChargeSeconds": 0.7   seconds to charge a boost stack (0.2 to 6)
              "hitsCostStacks": 0         1: each tree or building costs a stack again
    "smash":  "atomicBombFromStack": 2    the lowest stack that sets off the atomic bomb (1 to 8)
              "atomicBombCooldown": 4     seconds after a bomb before the next can go off (0 to 30)
- Something wrong? Search WorldBox's log for [Viltrumite]:
    %USERPROFILE%\AppData\LocalLow\mkarpenko\WorldBox\Player.log
  If a WorldFall update changes something the powers rely on, the mod switches itself off
  with one message and WorldFall carries on as normal.


Credits
-------
Flying, punching and landing sounds and animations come from the GTA V mod "Superman V2.2"
by JulioNIB (NIB Mods).
