MaterialPBR "Axiom_Hull"
{
	DiffColorScale (1.000 1.000 1.000)
	DiffColorConst (0.000 0.000 0.000)
	DiffMap "BnL/Axiom/hull-panels.*"
	PbrMap "BnL/Axiom/hull-pbr.*"
	RoughnessScale 1.00
	RoughnessConst 0.00
	MetallnessScale 1.00
	MetallnessConst 0.00
	AmbOcclScale 1.00
	BumpMap "BnL/Axiom/hull-bump.*"
	BumpHeight 2.0
	Reflections true
}

MaterialPBR "Axiom_Lower"
{
	DiffColorScale (0.720 0.700 0.700)
	DiffColorConst (0.000 0.000 0.000)
	DiffMap "BnL/Axiom/hull-panels.*"
	PbrMap "BnL/Axiom/hull-pbr.*"
	RoughnessScale 1.05
	RoughnessConst 0.00
	MetallnessScale 1.00
	MetallnessConst 0.00
	AmbOcclScale 1.00
	BumpMap "BnL/Axiom/hull-bump.*"
	BumpHeight 2.0
	Reflections true
}

MaterialPBR "Axiom_Dark"
{
	DiffColorScale (0.300 0.270 0.280)
	DiffColorConst (0.000 0.000 0.000)
	DiffMap "BnL/Axiom/hull-panels.*"
	PbrMap "BnL/Axiom/hull-pbr.*"
	RoughnessScale 1.10
	RoughnessConst 0.00
	MetallnessScale 1.60
	MetallnessConst 0.00
	AmbOcclScale 1.00
	BumpMap "BnL/Axiom/hull-bump.*"
	BumpHeight 2.0
	Reflections true
}

MaterialPBR "Axiom_Trim"
{
	DiffColorScale (1.000 0.990 0.975)
	DiffColorConst (0.000 0.000 0.000)
	DiffMap "BnL/Axiom/hull-panels.*"
	PbrMap "BnL/Axiom/hull-pbr.*"
	RoughnessScale 0.80
	RoughnessConst 0.00
	MetallnessScale 1.30
	MetallnessConst 0.00
	AmbOcclScale 1.00
	BumpMap "BnL/Axiom/hull-bump.*"
	BumpHeight 2.0
	Reflections true
}

Material "Axiom_Windows"
{
	DiffColor (1.000 1.000 1.000)
	DiffMap "BnL/Axiom/windows-diff.*"
	SpecColor (0.500 0.500 0.550)
	SpecPower 60
	Reflections true
	EmisMap "BnL/Axiom/windows-emis.*"
	EmisColor (1.000 1.000 1.000)
	EmisBright 1.5
}

Material "Axiom_Engine"
{
	DiffColor (0.100 0.090 0.140)
	DiffMap "BnL/Axiom/emis-white.*"
	EmisMap "BnL/Axiom/emis-white.*"
	EmisColor (0.569 0.325 0.953)
	EmisBright 2.5
}

Material "Axiom_Red"
{
	DiffColor (0.200 0.020 0.030)
	DiffMap "BnL/Axiom/emis-white.*"
	EmisMap "BnL/Axiom/emis-white.*"
	EmisColor (0.843 0.047 0.188)
	EmisBright 3.0
}

Material "Axiom_Amber"
{
	DiffColor (0.200 0.150 0.050)
	DiffMap "BnL/Axiom/emis-white.*"
	EmisMap "BnL/Axiom/emis-white.*"
	EmisColor (0.950 0.780 0.400)
	EmisBright 2.0
}

MaterialPBR "Axiom_Lettering"
{
	DiffColorScale (1.000 1.000 1.000)
	DiffColorConst (0.000 0.000 0.000)
	DiffMap "BnL/Axiom/axiom-text.*"
	PbrMap "BnL/Axiom/emis-white.*"
	RoughnessScale 0.50
	RoughnessConst 0.00
	MetallnessScale 0.10
	MetallnessConst 0.00
	AmbOcclScale 1.00
	Reflections true
	DiffMapAlpha "Transp"
}

Material "Axiom_Cool"
{
	DiffColor (0.150 0.150 0.180)
	DiffMap "BnL/Axiom/emis-white.*"
	EmisMap "BnL/Axiom/emis-white.*"
	EmisColor (0.850 0.880 1.000)
	EmisBright 2.0
}

MaterialPBR "Axiom_Logo"
{
	DiffColorScale (1.000 1.000 1.000)
	DiffColorConst (0.000 0.000 0.000)
	DiffMap "BnL/Axiom/logo.*"
	PbrMap "BnL/Axiom/emis-white.*"
	RoughnessScale 0.35
	RoughnessConst 0.00
	MetallnessScale 0.15
	MetallnessConst 0.00
	AmbOcclScale 1.00
	Reflections true
}

Material "Axiom_Bridge"
{
	DiffColor (1.000 1.000 1.000)
	DiffMap "BnL/Axiom/bridge-diff.*"
	SpecColor (0.600 0.600 0.650)
	SpecPower 80
	Reflections true
	EmisMap "BnL/Axiom/bridge-emis.*"
	EmisColor (1.000 1.000 1.000)
	EmisBright 1.5
}

Material "Axiom_Beacon"
{
	DiffColor (0.300 0.020 0.040)
	DiffMap "BnL/Axiom/emis-white.*"
	EmisMap "BnL/Axiom/emis-white.*"
	EmisColor (1.000 0.060 0.120)
	EmisBright 8.0
}

Material "Axiom_Strobe"
{
	DiffColor (0.400 0.400 0.400)
	DiffMap "BnL/Axiom/emis-white.*"
	EmisMap "BnL/Axiom/emis-white.*"
	EmisColor (1.000 1.000 1.000)
	EmisBright 8.0
}

